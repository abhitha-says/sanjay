# Forms

Zinsser's rule across every genre: there is no such thing as sports English or science English or business English. There is good English, and every field is written best by someone refusing to write in the local dialect. Read this file when the piece has a genre. The principles above it still apply.

---

## Business and institutional writing

Most people work for institutions, and most institutions write in a way that makes it hard to believe real men and women come to work there every morning. But just because people work for an institution, they do not have to write like one.

**The diagnosis.** Readers identify with people, never with abstractions like *profitability*, never with Latinate nouns like *utilization* and *implementation*, and never with inert constructions in which nobody can be visualized doing anything: *pre-feasibility studies are in the paperwork stage*.

Orwell's demonstration is still the shortest proof. Ecclesiastes:

> I returned and saw under the sun, that the race is not to the swift, nor the battle to the strong, neither yet bread to the wise, nor yet riches to men of understanding, nor yet favor to men of skill; but time and chance happeneth to them all.

Orwell's bureaucratic translation:

> Objective consideration of contemporary phenomena compels the conclusion that success or failure in competitive activities exhibits no tendency to be commensurate with innate capacity, but that a considerable element of the unpredictable must invariably be taken into account.

Notice first how the two look. The top one invites reading: short words with air around them, carrying the rhythms of human speech. The second is clotted with long words and tells us instantly that a ponderous mind is at work, so we do not start. Notice second what is gone: the race and the battle, the bread and the riches, and any sense of what one person did (*I returned*) or realized (*saw*).

**The pattern to look for in a client's own writing.** When people write to convey a human detail they write with humanity:

> It seems that traffic is beginning to pile up again in front of the school. If you can possibly do so, please come to the rear of the school for your child at the end of the day.

When the same people write about their professional work they vanish without a trace:

> In this document you will find the program goals and objectives that have been identified and prioritized. Evaluative procedures for the objectives were also established based on acceptable criteria.

The second one, rewritten by its own author after one workshop: *At the end of the year we will evaluate our progress.* Or: *We will see how well we have succeeded.*

**The repair, in order.**

1. **Locate the missing I.** Go to the engineer who conceived the system, the designer who designed it, the technician who assembled it, and get them to say in their own words how the idea came to them or how it will be used by real people in the real world. *I* is the most interesting element in any story.
2. **Push past the first answer.** Experts speak in acronyms because speaking simply would make them look like a jerk to their peers. Your responsibility is to the facts and the reader, not to the vanity of the expert. Keep going back until they are intelligible.
3. **Refuse to relinquish control.** In hierarchical companies, approval passes through successive levels and an undercurrent of fear says do things the company way. Most executives do not write what appears over their signature, and have surrendered the qualities that make them unique. If they and their institutions seem cold, it is because they acquiesced in being pumped up and dried out.
4. **Translate every sentence and see what is left.** *Companies are increasingly turning to capacity planning techniques to determine when future processing loads will exceed processing capabilities* means *it helps to know when you're giving your computer more than it can handle*. *The system is delivered with functionality* means it works. A customer will translate two sentences and then go find another company, thinking: if these guys are so smart, why can't they tell me what they do? Maybe they're not so smart.

**The stakes, stated plainly.** What you write is often the only chance you get to present yourself to someone whose business or money or good will you need. If what you write is ornate, pompous, or fuzzy, that is how you will be perceived. The reader has no other choice.

Managers at every level are prisoners of the notion that a simple style reflects a simple mind. A simple style is the result of hard work and hard thinking. A muddled style reflects a muddled thinker, or somebody too arrogant, too lazy, or too dumb to organize their thoughts.

**One counterexample worth keeping.** A New York subway sign, from a huge municipal bureaucracy: *If you ride the subway regularly you may have seen signs directing you to trains you've never heard of before. These are only new names for very familiar trains.* And a customer explaining why he picked a vendor: *A computer is like a sophisticated pencil. You don't care how it works, but if it breaks you want someone there to fix it.*

---

## Technical and scientific writing

Two fears meet here. Writers with a liberal arts background fear science. Engineers and scientists fear writing. Both were told something at an early age by a teacher and have lugged it through life. Neither is necessary, because **writing is thinking on paper**, and anyone who thinks clearly can write clearly about anything at all.

**The governing constraint.** Nowhere else must you work so hard to write sentences forming a linear sequence. This is no place for fanciful leaps or implied truths. Fact and deduction are the ruling family.

**The exercise that fixes disorderly thinking.** Describe how something works: a sewing machine, a pump, a fire extinguisher, the eye telling the brain what it sees. It forces you to make sure you know how it works, and then forces you to take the reader through the same sequence of ideas and deductions that made it clear to you. Zinsser watched a student who had been spraying the page with fuzzy generalities all semester turn into a writer overnight by doing exactly this.

**The tenet.** *The reader knows nothing.* Not flattering, and a technical writer can never forget it. You cannot assume readers know what you assume everybody knows, or that they still remember what was once explained to them.

**The upside-down pyramid.** Start at the bottom with the one fact a reader must have before they can learn anything more. The second sentence broadens the first, the third broadens the second, and you gradually move beyond fact into significance and speculation: how a discovery alters what was known, what avenues it opens, where it might be applied. There is no limit to how wide the pyramid can become, but readers understand broad implications only if they started with one narrow fact.

Zinsser's example is a *New York Times* front-page story that opens on a chimpanzee in California with a talent for playing ticktacktoe, and only afterward widens to computer analysis of brain waves, space flight, and eventually the whole international effort to understand the brain. It started with one chimp.

**Four ways to make an unfamiliar process land.**

1. **Find the human element.** If you have to settle for a chimpanzee, that is at least the next-highest rung on the Darwinian ladder.
2. **Use your own experience as a handle.** An article on memory that opens with the writer, thirty years later, still seeing the sand thrown in his face, hearing his father's voice, and feeling the anger burn in his chest.
3. **Build the story around someone else.** Berton Roueché's medical pieces are detective stories: an ordinary person struck by a mystifying ailment and a field epidemiologist obsessed with finding the villain. *At about 8 o'clock on Monday morning, a ragged, aimless old man of 82 collapsed on the sidewalk on Dey Street.* Not the medical history of poisoning. A man, and not just a man but a blue one.
4. **Reduce the abstract principle to an image the reader can see.** Moshe Safdie explaining that form is a by-product of evolution: the nautilus grows in a spiral because that is mathematically the only way its head will not get stuck in the opening; the vulture's wing bones form a space frame, thin in the middle and thicker at the ends, because it needs strength without weight; the giraffe's neck looks uneconomical until you notice most of its food is high in the tree.

**Precision of detail is the pleasure.** Diane Ackerman on bats: they vocalize up to 200,000 vibrations a second, in bursts twenty or thirty times a second, and judge speed and direction from the interval between echoes. Some can register a beetle walking on sand. Some can detect a moth flexing its wings as it sits on a leaf. Then ask yourself how many other examples she collected in order to choose those two. **Always start with too much material. Then give your reader just enough.**

**Write like a person, not like a scientist.** A discipline usually reported in dry pedantry is no reason to write in it. Lewis Thomas: *The man who catches a meningococcus is in considerably less danger for his life, even without chemotherapy, than the meningococci with the bad luck to catch a man.* Rachel Carson was not a writer; she was a marine biologist who wrote well, because she thought clearly and cared about her subject.

---

## Writing about people: the interview

Get people talking. Nothing so animates writing as someone telling what they think or what they do, in their own words.

Their words will always be better than yours, even if you are the most elegant stylist in the land. They carry the inflection of a speaking voice, the idiosyncrasies of how that person builds a sentence, the regionalisms of their conversation and the lingo of their trade, and their enthusiasms. This is a person talking to the reader directly, not through the filter of a writer. As soon as the writer steps in, everyone else's experience becomes secondhand.

**The first answer is seldom sufficient.** This is the single most useful interviewing rule in the book. Zinsser asks Roger Tory Peterson about his painting technique and gets one sentence. He asks how it differs from his earlier method: *Right now I'm straddling. I'm trying to add more detail without losing the simplified effect.* Then a stop. He asks why more detail now, at this point in his life, and finally gets the answer worth printing.

Ask *Why not?* and *What else?* Ask the dumb question. You are a generalist trying to make an expert's work accessible, which means prodding them to clarify statements so obvious to them that they assume they are obvious to everyone. If the expert thinks you are dumb, that is his problem.

**Get your best material on the way out.** *Have I seen everything?* Often the best thing arrives in the chitchat of leave-taking, when the person is off the hook after the hard work of making their life presentable to a stranger and thinks of a few afterthoughts. That question is what got Zinsser into the basement with two thousand bird specimens, including one tagged ACORN WOODPECKER, APRIL 10, 1882.

**Notice when you think *that's interesting*.** Pay attention and follow your nose. Trust your curiosity to connect with the reader's.

---

## Writing about places

The failure mode is the brochure. *Hong Kong affords many fascinating experiences to the curious sightseer.* Nobody wants it and nobody believes it.

Two rules. First, **the writer is the guide**: it is not enough to take readers on a trip, you must take them on your trip, which means giving them some idea of who you are, including your apprehensions. Second, **find the connection between yourself and the place**. Five separate interviews with the minister, the organist, the firemen, the sexton, and the choirmaster will produce five competent features and no piece. Go deeper, and be willing to sit with the place until it tells you what it means.

Detail is what makes a place real, and it must be detail nobody else would have bothered with: streets of sand rather than dirt, a clay mosque that looks like a sandcastle a child built on a beach, a Land Rover having its front tire pumped up by a boy with a bicycle pump.

---

## Memoir and personal writing

**Settle whose truth it is, in advance.** Are you writing as the child who was there, or as the adult you are now, bringing the wisdom of age to the credulities of childhood? The question has no single right answer, and it has to be answered before you draft. Readers will not put up with vacillation between two perspectives and tones.

**Reduce to one incident.** A student casts about for something to write about his town, offering X, then Y, then Z, all of them uninteresting even to him, until almost accidentally he stumbles on a long-forgotten memory, seemingly unimportant and unassailably true, that compresses into one incident everything that made him want to write about the town in the first place. Everybody in the room knows it when they hear it. The writer just needed time to find it.

**The quest is the strongest available shape.** Any time you can tell a story as a quest or pilgrimage you are ahead of the game, because readers bring their own associations and do some of your work for you.

---

## Opinion, criticism, and columns

Sell yourself and your subject will exert its own appeal. Believe in your own identity and your own opinions. Writing is an act of ego; you might as well admit it and use the energy to keep going.

The failure is equivocation. Zinsser's hall of fame: *We see nothing but increasingly brighter clouds every month.* *There's continuing ground for serious concern and the situation remains serious. The longer it remains serious, the more ground there is for serious concern.* *I am not in that mode. I am in the mode of being deeply concerned.* And the champion, a thirteen-word sentence with five hedging words: *And yet, on balance, affirmative action has, I think, been a qualified success.*

Leaders who bob and weave like aging boxers do not inspire confidence or deserve it. The same is true of writers.

---

## Humor

Humor is the writer's secret weapon and it is not a decoration. Zinsser: it takes audacity, exuberance, and gaiety, and the most important is audacity. S. J. Perelman's line, which he calls the entire case for enjoyment: **the reader has to feel that the writer is feeling good.** Then Perelman added, *even if he isn't*. He went to his typewriter every day through more than the usual share of depression and made the English language dance. He cranked it up.

Practical rules. Let humor sneak up so the reader hardly hears it coming. Understatement beats overstatement every time. Never signal a joke with an exclamation point, which robs readers of the pleasure of finding it funny themselves. If something amuses you in the act of writing, put it in; it can always be taken out, and only you can put it in.

---

## Writing about a field you love

Zinsser's sports chapter generalizes to any enthusiast subject, including software.

**The trade dialect is not richness, it is exhaustion.** Southpaws and portsiders, hurlers and twirlers, netmen and matmen, the old pigskin. The man who first thought of *southpaw* had a right to a small smile. Decades of repetition have paled it. These words have become cheaper currency than the coins they replaced. We read to find out who won, and we do not read with enjoyment.

The direct software equivalent: *blazing fast*, *battle-tested*, *bulletproof*, *rock-solid*, *out of the box*, *under the hood*, *first-class citizen*, *heavy lifting*, *single source of truth*, *dogfooding*, *north star metric*. Every one was a good coinage once.

**Never rename a thing to avoid repeating its name.** One paragraph of college sportswriting turns Bob Hornsby into the gangling junior, the Memphis native, the Exeter graduate, the racquet ace, and the redhead, while his opponent becomes the Green captain, the Indian, the Hanover mainstay, and the Yankee. Readers do not know them in these disguises and do not care. They only want the clearest picture of what happened. The cure is worse than the ailment.

**Do not drown the reader in numbers.** Some statistics matter more than others. If a pitcher wins his twentieth game, mention it. Do not write five paragraphs of conference records in which the only person served is the man finally off the hook for a 1951 interception record.

**You are not the story.** Half of modern sportswriters think they are Maupassant, masters of the exquisitely delayed lead; the rest think they are Freud, privy to the athlete's psychic wounds. Readers want to know how the players played and how the game came out. Please tell us.

**What raises the writing above the beat** is the same thing everywhere: people and places, time and transition, and the human bond. Updike on Ted Williams's last game does not add to the record of the famous swing; he suggests that baseball, with its graceful intermittences of action and its dispassionate mathematics, is essentially a lonely game and therefore suited to a loner. Baseball lonely? Think about it, Updike says.

Hang around the track and the stable, the stadium and the rink. Observe closely. Interview in depth. Listen to old-timers. Ponder the changes. Write well.
