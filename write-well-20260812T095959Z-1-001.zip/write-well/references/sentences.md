# Sentences

Zinsser's chapter of scraps and morsels, expanded. Read this when the question is about a single sentence or a pair of them. Everything here is from *On Writing Well* unless marked.

---

## Verbs

Verbs are the most important tools you have. They push the sentence forward and give it momentum. Active verbs push hard; passive verbs tug fitfully.

*Joe saw him* is strong. *He was seen by Joe* is weak: longer, insipid, and ambiguous. Once? Every day? Once a week? A style built on passive constructions saps the reader's energy, because nobody ever quite knows what is being perpetrated by whom and on whom.

Passive-voice writers tend to prefer long Latinate words to short Anglo-Saxon ones, which compounds the trouble and makes the sentences still more glutinous. Use the passive only when there is no comfortable way around it: when the actor is genuinely unknown, or genuinely irrelevant, or when keeping a consistent subject across several sentences matters more.

**Choose verbs with color.** *Glitter, dazzle, twirl, beguile, scatter, swagger, poke, pamper, vex.* English has an unusually large supply of verbs bright with color. Never settle for one that is dull or merely serviceable.

**Avoid verbs that need a preposition to finish their work.** Do not set up a business you can start. Do not say the president stepped down: did he resign, retire, or get fired? Be precise.

For active verbs at their best, Zinsser sends you not to Hemingway or Thurber but to the King James Bible and Shakespeare.

---

## Adverbs

Most are unnecessary. You clutter the sentence and annoy the reader when you pick a verb with a specific meaning and then add an adverb carrying the same meaning.

The radio does not blare loudly; *blare* connotes loudness. Nobody clenches their teeth tightly; there is no other way to clench teeth. The winning athlete did not grin widely. Not *effortlessly easy*: use *effortless*. Not *totally flabbergasted*: the beauty of *flabbergasted* is that it implies an astonishment that is total, and nobody is partly flabbergasted. And *slightly spartan* is a monk's cell with wall-to-wall carpeting.

Retire *decidedly* and its slippery cousins. Situations are decidedly better and decidedly worse, but you never learn how decided the improvement was or who did the deciding. Same for *eminently*, *arguably*, *admittedly*, *virtually*. Is the pitcher, provably, the best on the team? Then omit *arguably*.

---

## Adjectives

Also mostly unnecessary, and sown into prose by writers who do not stop to notice the concept is already in the noun. Precipitous cliffs. Lacy spiderwebs. Yellow daffodils. Brownish dirt. Gnarled oaks, stately elms, frisky kittens, hard-bitten detectives, sleepy lagoons. This is adjective-by-habit.

Make your adjectives do work that needs doing. *He looked at the gray sky and the black clouds and decided to sail back to the harbor.* The darkness is the reason for the decision, so it earns its place. If the dirt in that part of the country is red, mention the red dirt. If you want a value judgment about daffodils, choose *garish*.

The adjective that exists only as decoration is a self-indulgence for the writer and a burden for the reader. Use them sparingly and the ones you keep will have their proper power.

---

## Little qualifiers

Prune the small words that qualify how you feel and what you saw: *a bit, a little, sort of, kind of, rather, quite, very, too, pretty much, in a sense, somewhat, fairly, relatively, slightly, mostly, generally.*

Do not say you were a bit confused and sort of tired and a little depressed and somewhat annoyed. Be confused. Be tired. Be depressed. Be annoyed.

*Very* achieves emphasis occasionally and is clutter most of the time. Someone is methodical or is not. *Spectacular* and *awesome* do not submit to measurement, so *rather spectacular* means nothing.

The real point is authority. Every little qualifier whittles away a fraction of the reader's trust. Readers want a writer who believes in what they are saying. Do not be kind of bold. Be bold.

---

## Concept nouns

Nouns expressing a concept, used where a verb telling what somebody did belongs. The eerie thing about these sentences is that they have no people in them and no working verbs, only *is* and *isn't*, with all the meaning packed into an abstraction.

| Dead | Alive |
|---|---|
| The common reaction is incredulous laughter. | Most people just laugh with disbelief. |
| Bemused cynicism isn't the only response to the old system. | Some people respond to the old system by turning cynical; others say... |
| The current campus hostility is a symptom of the change. | It's easy to notice the change: you can see how angry all the students are. |

Do not get caught holding a bag full of abstract nouns. You will sink to the bottom of the lake and never be seen again.

---

## Creeping nounism

Two or three nouns strung together where one noun, or better one verb, will do. Nobody goes broke now; we have money problem areas. It no longer rains; we have precipitation activity, or a thunderstorm probability situation. Please, let it rain.

Four and five nouns now attach to each other like a molecule chain. Zinsser's specimen: **Communication facilitation skills development intervention.** Not a person in sight, not a working verb. He thinks it is a program to help students write.

The modern software version is identical: *customer engagement optimization framework*, *data quality assurance process improvement*. Same repair: find the person, find the verb.

---

## Punctuation

**The period.** Most writers do not reach it soon enough. If you are hopelessly mired in a long sentence, it is usually because you are asking it to carry two dissimilar thoughts. Break it into two, or three. There is no minimum length for a sentence acceptable in the eyes of God. Among good writers the short sentence predominates.

**The exclamation point.** Do not use it unless you must for a specific effect. It has a gushy aura, the breathless excitement of a debutante. Above all do not use it to notify the reader that you were making a joke or being ironic; readers are annoyed by the reminder and robbed of the pleasure of finding it funny themselves. Construct the sentence so word order puts the emphasis where you want it.

**The semicolon.** There is a nineteenth-century mustiness about it. It brings the reader, if not to a halt, at least to a pause, and it will slow your prose to a Victorian pace. Use it sparingly, usually to add a related thought to the first half of a sentence. Rely instead on the period and the dash.

**The dash.** Widely regarded as not quite proper, and it has full membership. Two legitimate uses. First, to amplify or justify in the second half of a sentence a thought stated in the first: *We decided to keep going, it was only 100 miles more and we could get there in time for dinner.* By its shape the dash pushes the sentence ahead. Second, a pair of them setting off a parenthetical inside a longer sentence, dispatching along the way an explanatory detail that would otherwise need its own sentence. (Beyond those two uses it becomes a rhythm tic; see `machine-tells.md` section 6.)

**The colon.** More antique-looking than the semicolon, and many of its jobs have gone to the dash. It still does one thing better than anything else: bringing the sentence to a brief halt before an itemized list.

---

## Mood changers

Alert the reader to a change of direction as early as possible. At least a dozen words do this job: *but, yet, however, nevertheless, still, instead, thus, therefore, meanwhile, now, later, today, subsequently.*

It is far easier to process a sentence that starts with *but* when the direction shifts, and far harder when the reader must wait until the end to learn you shifted.

**Unlearn the rule against starting with *but*.** There is no stronger word at the start. It announces total contrast and primes the reader for the change. If you need relief from too many, switch to *however*, which is weaker and needs careful placement: never at the start, where it hangs like a wet dishrag, and never at the end, by which time it has lost its howeverness. Put it as early as you reasonably can, three or four words in, where its abruptness becomes a virtue.

*Yet* and *nevertheless* do nearly the same job. Each replaces a whole dismal summarizing clause: *Despite the fact that all these dangers had been pointed out to him, he decided to go* becomes *Yet he decided to go*.

*Meanwhile, now, today, later* save confusion as well as words, because careless writers change their time frame without telling anyone. *Now I know better. Later I found out why. Today you can't find such an item.* Always ask where you left the reader in the previous sentence.

---

## The link between sentences

> The tragic hero of the play is Othello. Small and malevolent, Iago feeds his jealous suspicions.

Nothing is wrong with the Iago sentence on its own. As a sequel it is badly wrong, because the name lingering in the reader's ear is Othello, and the reader naturally assumes Othello is small and malevolent.

Read aloud with these connecting links in mind and you will hear a dismaying number of places where you lost the reader, confused the reader, failed to tell them the one fact they needed, or told them the same thing twice. Those are the inevitable loose ends of every early draft.

---

## Paragraphs

Keep them short. Writing is visual and catches the eye before it catches the brain. Short paragraphs put air around the text and make it look inviting; a long chunk of type discourages a reader from starting at all.

Do not go berserk in the other direction. A succession of tiny paragraphs is as annoying as one that is too long, and the verbless midget paragraph is condescension wearing a friendly face: *Yoo-hoo! Look how simple I'm making this for you!* It actually makes the reader's job harder by chopping up a natural train of thought.

Good nonfiction writers think in paragraph units, not sentence units. Each paragraph has its own integrity of content and structure, and the sequence of them is a road map telling the reader how you organized your ideas.

---

## Sound and rhythm

Readers hear what they read far more than you realize, so rhythm and alliteration matter in every sentence.

E. B. White's demonstration, on Thomas Paine's *These are the times that try men's souls*:

> Times like these try men's souls.
> How trying it is to live in these times!
> These are trying times for men's souls.
> Soulwise, these are trying times.

Paine's version is poetry and the other four are oatmeal. Nothing changed but the arrangement.

Good prose writers are part poet, always listening. If all your sentences move at the same plodding gait, read them aloud and you will begin to hear where the trouble is. Gain variety by reversing the order of a sentence, by substituting a word with freshness or oddity, or by altering length so they do not all sound as though they came out of the same mold. An occasional short sentence carries a tremendous punch and stays in the reader's ear.

Word choice includes sound. *Serene* and *tranquil* mean nearly the same thing; one is soft, the other strangely disturbing because of its unusual *n* and *q*. Choose for emotional weight, not just denotation.

Zinsser wrote entirely by ear and read everything aloud before letting it out into the world.

---

## Contractions

Your style will be warmer and truer to your personality with *I'll*, *won't*, *can't* where they fit comfortably. *I will be glad to see them if they do not get mad* is stilted; read it aloud and hear it.

One form to avoid: *I'd*, *he'd*, *we'd*, because they mean both *had* and *would*, and readers get well into the sentence before finding out which, often the wrong one. Never invent contractions like *could've*; they cheapen your style. Stick to the ones in the dictionary.

---

## That and which

Always use *that* unless it makes your meaning ambiguous. The belief that *which* is more correct, more literary, more acceptable is a residue from school. It is not. In most situations *that* is what you would naturally say and therefore what you should write.

If the sentence needs a comma to achieve its precise meaning, it probably needs *which*.

- *Take the shoes that are in the closet.* Not the ones under the bed. No comma.
- *Take the shoes, which are in the closet.* Only one pair is under discussion; the clause tells you where they are. Comma required.

A high proportion of *which* usages narrowly describe, identify, locate, or explain the phrase before the comma: *The house, which has a red roof. The Rhine, which is in Germany. The monsoon, which is a seasonal wind.*

---

## Overstatement and credibility

The living room did not look as if an atomic bomb had gone off there. Ten 747s were not flying through your brain, and you did not seriously consider jumping out the window. These verbal high jinks can get just so high before the reader feels an overpowering drowsiness, like being trapped with a man who cannot stop reciting limericks.

Credibility is as fragile for a writer as for a president. Catch the reader once with a bogus statement passed off as true and everything you write afterward is suspect. Life has more than enough genuinely funny situations. Let the humor sneak up so the reader hardly hears it coming.

---

## Pronouns and inclusive language

Zinsser rewrote three or four hundred sentences across editions to remove the generic *he*, mainly by switching to the plural, and reported that the sky did not fall in. His preferences, and the reasoning, still hold up:

- Plurals work but weaken writing in bulk, because they are less specific and harder to visualize. Use them, do not lean on them.
- *He or she* works in small doses and clogs the language when used everywhere.
- *He/she* is out; the slant has no place in good English.
- Best solutions change something else in the sentence. *We* replaces *he*; *our* and *the* replace *his*. *First he notices what's happening to his kids and he blames it on his neighborhood* becomes *First we notice what's happening to our kids and we blame it on the neighborhood.* General nouns replace specific ones: *Doctors often neglect their wives and children* becomes *Doctors often neglect their families.*
- **You** is the underused one, and a godsend in instructional writing. Addressing the reader directly is one of the most reassuring sounds a reader can hear: Dr. Spock talking to the mother of a feverish child, Julia Child talking to a cook stalled mid-recipe. Always look for ways to make yourself available to the people you are trying to reach.

(Modern note, not Zinsser's: singular *they* is now standard and solves most of what he was working around. Use it. His underlying instruction, which does not date, is to avoid constructions implying only men can be settlers, engineers, or founders, and to avoid the words that patronize or diminish.)

---

## The quickest fix

Surprisingly often a difficult problem in a sentence is solved by getting rid of it, and this is usually the last solution that occurs to writers in a jam. First they move the troublesome phrase somewhere else, then rephrase it, then add words to clarify it, and each effort makes it worse. The writer concludes there is no solution.

Look at the troublesome element and ask: do I need it at all? Probably not. It was trying to do an unnecessary job all along, and that is why it was giving you so much grief. Remove it and watch the sentence spring to life and breathe normally.
