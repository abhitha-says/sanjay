# Structure

The most untaught and underestimated skill in nonfiction is organizing a long piece. Writers are endlessly taught to write a clear declarative sentence. Ask them for an article and the sentences leach out all over the floor like marbles.

Writing is linear and sequential. Logic is the glue. Tension has to hold from one sentence to the next, one paragraph to the next, one section to the next, and narrative is what pulls the reader along without their noticing the tug. The only thing they should notice is that you made a sensible plan for the journey.

---

## The unities

Unity is the anchor. It keeps the reader from straggling off, and it satisfies a subconscious need for order that reassures them all is well at the helm. Choose among the variables and hold your choice.

**Unity of pronoun.** First person as participant, third person as observer, or second person. Pick one.

**Unity of tense.** Most writing runs on past tense; present works too. What does not work is switching. You may use more than one tense, since the whole purpose of tenses is to handle time in its gradations, but you must choose the tense in which you principally address the reader, however many glances you take backward or forward.

**Unity of mood.** Casual, formal, ironic, involved, detached, amused. Any tone is acceptable. Two or three mixed together is not.

The classic failure is the travel piece where a real person tells you about arriving in Hong Kong with his wife Ann, then turns without warning into a brochure (*One can ride the picturesque ferry and gawk at the myriad sampans*), then into a guidebook (*To enter Hong Kong it is necessary to have a valid passport*). The sampans and the passport rules are not the problem. The problem is that the writer never decided who he was addressing us as. Instead of controlling his material, his material controls him.

Ask before starting: In what capacity am I addressing the reader? What pronoun and tense? What style: impersonal reportorial, personal but formal, personal and casual? What attitude toward the material: involved, detached, judgmental, ironic, amused? How much do I want to cover? What one point do I want to make?

**When the material pulls you somewhere else, go.** The act of writing generates thoughts you did not anticipate. Do not fight a current that feels right; trust material that takes you into terrain you did not intend to enter but where the vibrations are good. Never become the prisoner of a preconceived plan. Then go back and rewrite the first half so mood and style are consistent from start to finish. Scissors and paste are honorable tools.

---

## Reduce before you write

Most nonfiction writers have a definitiveness complex: they feel obliged to the subject, to their honor, to the gods of writing, to make the piece the last word. There is no last word. Writers who pursue every last fact are pursuing a rainbow and never settle down to write.

Nobody can write a piece *about* something. Tolstoy could not write a book about war and peace, and Melville could not write a book about whaling. They made reductive decisions about time, place, and individual characters: one man pursuing one whale.

**Every writing project must be reduced before you start.** Decide what corner of the subject you are biting off, cover it well, and stop. You will often find that along the way you managed to say most of what you wanted to say about the whole subject.

This is also a question of energy and morale. An unwieldy task drains your enthusiasm, and enthusiasm is the force that keeps the reader in your grip. When your zest begins to ebb, the reader is the first person to know it.

**One point.** Every successful piece leaves the reader with one provocative thought they did not have before. Not two, not five. One. Deciding it early tells you what route to follow and what destination to reach, and it also settles tone: some points are best made by earnestness, some by dry understatement, some by humor.

**Focus.** Of all the possible stories inside this material, which one is yours? A woman planning to write about her childhood home wanted to start by interviewing all ten of her brothers and sisters. Was the story theirs or hers? Hers. Then the interviews are a nearly complete waste of time and energy. Only after settling that did she see the shape of what she was writing.

**Compression.** How to distill a coherent narrative from a tangled mass of facts and feelings. Nobody can write about the disappearance of small towns in Iowa; it would be all generalization and no humanity. Write about one town, and inside that town reduce further, to one store or one family or one farmer, and thereby tell the larger story.

---

## The lead

The most important sentence in any piece is the first one. If it does not induce the reader to proceed to the second, the piece is dead, and if the second does not deliver them to the third, equally dead. A lead is a progression of such sentences, each tugging the reader forward until they are hooked.

There is no fixed length. Some leads hook with a few well-baited sentences; others amble for pages, exerting a slow steady pull. The only valid test is: does it work? Yours may not be the best of all possible leads, but if it does the job, be thankful and proceed.

**What a lead must do, in order.**

1. Capture the reader immediately with freshness, novelty, paradox, humor, surprise, an unusual idea, an interesting fact, or a question. Anything that nudges curiosity and tugs at a sleeve.
2. Do real work: hard details telling the reader why the piece was written and why they should read it. Do not dwell on the reason. Coax a little more; keep them inquisitive.
3. Keep building. Every paragraph amplifies the one before. Give more thought to solid detail and less to entertaining.
4. Take special care with the last sentence of each paragraph. It is the springboard to the next. Give it an extra twist of humor or surprise, like the snapper at the end of a stand-up routine. Make the reader smile and you have them for one more paragraph.

**Kinds of lead that work.**

- *The narrative.* Just tell a story, starting inside the action. The oldest and most compelling method of holding attention; everybody wants to be told a story. Edmund Wilson opens the discovery of the Dead Sea Scrolls with a Bedouin boy minding goats who idly throws a stone into a cave and hears an unfamiliar sound of breakage. No stage-setting, no alarm clock before daylight.
- *The two-sentence hook.* "I've often wondered what goes into a hot dog. Now I know and I wish I didn't."
- *The odd fact.* A piece of slippery elm bark in a display case at the Baseball Hall of Fame, which a pitcher chewed to increase saliva for throwing spitballs. Salvation often lies not in your style but in some odd fact you were able to discover.
- *The accumulation of pathos.* Joan Didion opening on 7000 Romaine Street: a middle-class slum, people who once processed fan photographs or knew Jean Harlow's manicurist, chicken-wire glass in the windows, and a dusty welcome mat at a door that is locked because the building belongs to Howard Hughes.
- *The whole story in one sentence.* *In the beginning God created heaven and earth.* *The problem lay buried, unspoken, for many years in the minds of American women.* *You know more than you think you do.*

**Where odd facts come from.** Not from the obvious sources and the obvious people. Read signs, billboards, the junk written along the roadside, package labels, toy instructions, medicine claims, graffiti, menus, catalogs, second-class mail, the fillers that come spilling out of your bank statement, obscure crannies of the newspaper. You can tell the temper of a society by what patio accessories it wants. Our daily landscape is thick with absurd messages, and they are often just quirky enough to make a lead that is different from everybody else's.

Zinsser found his spitball lead only because instinct told him to go back to the museum for one more tour the next morning. Collect more material than you will use. Every piece is strong in proportion to the surplus you chose from.

**Leads to retire.** The future archaeologist stumbling on the remains of our civilization. The creature from Mars amazed by scantily clad earthlings. The cute event that happened *one day not long ago* or on a conveniently recent Saturday. The what-did-these-people-have-in-common quiz. (Modern additions: the dictionary definition, *In today's fast-paced world*, the rhetorical question aimed at *you*, and the statistic with no source.)

**The three-paragraph test.** Editors routinely throw away the first three or four paragraphs of an article, or the first few pages, and start where the writer began to sound like themselves. Those opening paragraphs are impersonal, ornate, and say nothing; they are a self-conscious attempt at a fancy introduction. Apply the test to your own draft before anyone else does. What you are looking for is the sentence where a person shows up.

---

## Section breaks

An asterisk or a blank line is a signpost. It tells the reader you have organized this piece and that a new phase begins: a change of chronology, subject, emphasis, or tone. After a highly compressed lead it lets you take a breath and start again at the more leisurely gait of a storyteller.

It helps you as much as the reader. Breaking material into manageable chunks lets you take one chunk at a time, which makes the total task seem less formidable and staves off panic.

---

## Keeping the middle alive

- **Ask after every sentence what the reader wants to know next**, and answer that. This is the whole discipline of sequence.
- **Get other people to do work for you.** A quoted brochure, sign, or memo is often more revealing than your own description of it, and its language can be an amusement in itself. Watch for funny or self-serving quotes and use them with gratitude.
- **Use resonance.** A reference the reader already carries does emotional work you cannot do alone. Zinsser invokes *Beau Geste* and *The Four Feathers* in the Timbuktu piece and lets the reader's own associations supply the dread. Choose references your actual reader holds, not the ones that flatter you.
- **Plant small jokes to keep yourself amused.** They keep the reader in a good mood and propel them into the next paragraph.
- **Keep asking: what is this really about?** Not *what is it about*. Fondness for material you went to trouble to gather is not a reason to include it. Self-discipline bordering on masochism is required, and the consolation is that cut material is not lost: it stays in the writing as something the reader can sense. Readers should always feel you know more than you put down.

---

## The ending

Give as much thought to your last sentence as to your first. Well, almost as much.

Most of us are prisoners of the lesson pounded in by composition teachers: beginning, middle, and end, with Roman numerals, and a promise to get back to III and summarize the journey. That is fine for students uncertain of their ground. To write good nonfiction you must wriggle out of III's grip.

**You have arrived at III when a sentence appears beginning *In sum, it can be noted that* or a question asking *What insights, then, have we been able to glean*.** These signal that you are about to repeat in compressed form what you already said in detail. The reader's interest falters, the tension you built sags, and they hear the laborious sound of cranking. They notice what you are doing and how bored you are by it. Then they quit.

**When you are ready to stop, stop.** If you have presented the facts and made your point, look for the nearest exit. Often a few sentences wrap things up.

The perfect ending takes readers slightly by surprise and yet seems exactly right. They did not expect the piece to end so soon, or so abruptly, or to say what it said, and they know it when they see it. It is the curtain line in a comedy: we are in the middle of a scene, an actor says something outrageous or epigrammatic, and the lights go out. What delights us is the playwright's control.

**Endings that work.**

- *A quotation* with finality, humor, or an unexpected closing detail. Usually the best option. Go back through your notes; often you thought *that's my ending* when you first heard it. Zinsser ends a profile of a young Woody Allen on: "I'm obsessed by the fact that my mother genuinely resembles Groucho Marx."
- *A flat fact*, uncommented, that reframes what came before. Mencken on Coolidge: "There were no thrills while he reigned, but neither were there any headaches. He had no ideas, and he was not a nuisance." Five short sentences and an arresting thought to take along.
- *Full circle*: an echo of a note struck at the beginning, which completes the journey with its resonance.

**You are not obliged to the actual shape of events.** The Timbuktu piece was supposed to end with the caravan reaching the market and the salt being sold. The nearer Zinsser got to writing that section, the more it loomed as drudgery. He realized the real climax had already happened, in a nomad family with almost no possessions offering to share their dinner, and he ended there. When your story tells you it is over, regardless of what subsequently happened, look for the door. Pause only long enough to check the unities: the person who started the piece should be the person ending it.

---

## Zinsser's own method, annotated

The most useful single artifact in the book is chapter 23, where he takes his Condé Nast Traveler piece on Timbuktu apart decision by decision. The moves worth stealing:

**Open on one perception, not a summary.** *What struck me most powerfully when I got to Timbuktu was that the streets were of sand. I suddenly realized that sand is very different from dirt. Every town starts with dirt streets that eventually get paved as the inhabitants prosper and subdue their environment. But sand represents defeat. A city with streets of sand is a city at the edge.* Five sentences, plain declarative, not a comma in sight, one thought each.

**Acknowledge what the reader already half knows** before you correct it. That welcomes them as a fellow traveler bringing the same emotions to the trip.

**Cram the necessary history into as few sentences as it takes and then leave.** Three sentences covered the founding, the explorers, the caravan routes, and the collapse. Do not give a magazine reader more than they need; if you want to tell more, write a book.

**Establish your persona early and keep it.** *Six men and women bright enough or dumb enough, we didn't yet know which.* Gullibility used in moderation gives the reader the pleasure of feeling superior, and it is one of the oldest strains in travel and humor writing.

**Spend real time on individual words.** *We were in our fifties and sixties* became *from late middle age to Medicare*. *London and Paris didn't turn up* became *Venice and Versailles didn't bob up*, after rejecting Rome, Cairo, Athens, Bangkok, Madrid, Moscow, Tel Aviv, Tokyo, and Vienna, and after replacing *turn up* with a three-letter verb that paints a picture of something rising periodically to the surface. That one sentence took an hour, and both writer and reader can tell when finicky labor was rewarded.

**Drop the bomb flat.** *Mali got its independence in 1960. We were in Timbuktu for an event that hadn't been held in 27 years.* No exclamation point, no comment. Adding one would have spoiled the reader's own pleasure of discovery.

**Get on the plane.** The last thing in the chapter, and the least technical. If a subject interests you, go after it, even if it is in the next county. It is not going to come looking for you. Decide what you want to do. Then decide to do it. Then do it.
