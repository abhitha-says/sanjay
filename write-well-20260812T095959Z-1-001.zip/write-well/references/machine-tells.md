# Machine tells

Everything here supports **Pass 3: Second choice**. Read it as a detection aid, not a find-and-replace table. A phrase on these lists is a signal that you drifted toward the average, and the repair is to go find the fact underneath, not to reach for a synonym one shelf over.

Zinsser's own lists are marked (Z). The rest is the modern set, which he did not live to see but diagnosed anyway when he wrote that journalese is a quilt of instant words patched together out of other parts of speech, and that a writer using them announces on sight that they are a hack.

---

## 1. The move that matters

Almost every repair in this file is the same move: **from the category to the member.**

| Category (what arrives automatically) | Member (what is true) |
|---|---|
| various stakeholders | the two founders and their lawyer |
| significant performance improvements | 2.4 seconds down to 300 milliseconds |
| a wide range of industries | dentists, food trucks, and one funeral home |
| users reported challenges | four people emailed to say they could not find the export button |
| recently | last Tuesday |
| a number of issues | the login loop and the duplicate charge |
| leading companies | Stripe and one bank that asked not to be named |
| in the enterprise space | at companies with more than 500 people |
| enhanced security posture | we rotate keys every 24 hours instead of never |
| streamlined the onboarding process | cut signup from nine screens to two |

If you cannot name the member, you do not know the fact. Ask the user for it or mark it `[NEED: ...]`. Do not invent one.

---

## 2. Long word standing where a short one fits (Z)

| Reach for | Write |
|---|---|
| assistance | help |
| numerous | many |
| facilitate | ease |
| individual | man, woman, person |
| remainder | rest |
| initial | first |
| implement | do, build, ship |
| sufficient | enough |
| attempt | try |
| referred to as | called |
| utilize, utilization | use |
| commence | start |
| terminate | end, stop, fire |
| purchase | buy |
| residence | home, house |
| endeavor | try |
| ascertain | find out |
| currently, at the present time, presently | now |
| experiencing | (the actual verb: hurts, rains, breaks) |
| prioritize | rank |
| methodology | method |
| approximately | about |
| in the event that | if |
| prior to | before |
| subsequent to | after |
| additional | more |
| demonstrate | show |
| indicate | show, say |
| obtain | get |
| require | need |
| provide | give |
| possess | have |

The dentist who asks whether you are *experiencing any pain* would ask his own kid *does it hurt?* The longer phrase does two things at once: it makes him sound more important, and it blunts the painful edge of truth. Watch for both motives in your own drafts.

---

## 3. Phrase standing where a word fits (Z)

| Reach for | Write |
|---|---|
| due to the fact that | because |
| with the possible exception of | except |
| until such time as | until |
| for the purpose of | for, to |
| in order to | to |
| at this point in time | now |
| he totally lacked the ability to | he couldn't |
| has the capability of | can |
| is in a position to | can |
| it is possible that | may |
| a large number of | many |
| the majority of | most |
| in the vicinity of | near |
| on a regular basis | regularly, weekly |
| in terms of | (recast the sentence) |
| with regard to, with respect to | about |
| in the context of | in |
| serves as, stands as, acts as, functions as | is |
| plays a role in | (name the actual verb) |
| when it comes to | (delete, start with the subject) |

The last three are copula avoidance: the writer flinching from the plain verb *to be*. *X serves as a reminder that* is *X reminds us that*, and usually *X* alone.

---

## 4. Announcements of what you are about to say (Z)

Delete the announcement. If it should be pointed out, point it out.

*I might add. It should be noted that. It is worth mentioning. It is interesting to note. It's important to understand. Let me be clear. The truth is. Here's the thing. What's fascinating is. One thing to keep in mind. Before we dive in. Let's take a closer look. Now, you might be wondering. So what does this mean?*

Are we not all stupefied by what follows when someone says *this will interest you*?

---

## 5. The modern vocabulary set

Not Zinsser's, but exactly what he meant by faddish words that will smother what you write. These are high-probability tokens, which is precisely why they read as machine output: they are the words most likely to appear, not the words most likely to be true.

**Verbs:** delve, leverage, navigate (abstract), underscore, foster, bolster, garner, elevate, unlock, harness, embark, spearhead, streamline, revolutionize, empower, curate, amplify, cultivate, illuminate, unpack, showcase, emphasize, resonate with, align with, dive into.

**Nouns:** tapestry, testament, landscape (abstract), realm, ecosystem, journey (abstract), cornerstone, hallmark, paradigm, framework (when nothing is framed), synergy, insight (as filler), narrative (meaning *story* or *claim*), space (meaning *industry*), lens, nuance, plethora, myriad, wealth (of options), array, suite, toolkit, blueprint, roadmap (metaphorical), game-changer, deep dive, north star.

**Adjectives:** robust, seamless, holistic, multifaceted, nuanced, comprehensive, cutting-edge, state-of-the-art, transformative, innovative, dynamic, vibrant, intricate, meticulous, enduring, profound, meaningful, impactful, actionable, unparalleled, unprecedented, bespoke, curated, powerful (of software), rich (of features), pivotal, crucial, vital, key, essential, significant, critical.

The last six deserve a note. *Crucial, pivotal, vital, key, essential, significant* are almost never doing work. They are the writer asserting importance instead of demonstrating it. If the thing is important, the fact will show it; if the fact does not show it, the adjective will not rescue it.

**Adverbs and connectives:** moreover, furthermore, additionally, notably, importantly, significantly, ultimately, essentially, fundamentally, arguably, indeed, that being said, with that said, in conclusion, at the end of the day, all in all, needless to say.

**Set phrases:** in today's fast-paced world, in an increasingly [X] world, ever-evolving, rapidly changing, more than ever before, now more than ever, the world of, a wide range of, a variety of, one of the most, whether you're a beginner or an expert, from X to Y and everything in between, it's not just about X, look no further, the possibilities are endless, only time will tell, the perfect blend of, take your X to the next level, unlock the full potential of, we've got you covered.

---

## 6. Construction patterns

Vocabulary is the easy tell. These are the structural ones, and they survive a word-level rewrite untouched, which is why substitution alone never fixes machine prose.

**The antithesis reflex.** *Not just X, but Y. It's not about X, it's about Y. X isn't merely Y; it's Z. More than a tool, it's a partner.* This construction pretends to make a distinction while making none. Delete the negated half. If the sentence collapses, there was nothing there.

**The reflexive tricolon.** Three items in every list, three clauses in every sentence, three examples for every claim, three sections in every piece. Real material rarely comes in threes. Use two when you have two and five when you have five, and let a list end on an odd note.

**The participial tack-on.** A present participle glued to the end of a sentence to manufacture significance: *...ensuring reliability at scale*, *...making it an ideal choice for teams*, *...highlighting the importance of early testing*, *...contributing to the company's continued growth*, *...allowing users to focus on what matters*. Cut the clause. Read the sentence without it. It is almost always better and always more honest.

**The significance clause, non-participial form.** *This matters because...*, *The implication is clear:*, *This speaks to a broader trend of...*. Same fault, same repair. Trust the material.

**The false-balance paragraph.** Every claim followed by an acknowledgment of the other side, uniformly, regardless of whether the other side has a case. It reads as fairness and functions as evasion. Acknowledge an objection when the objection is real and you intend to answer it. Otherwise state the claim and stand behind it.

**Uniform hedging.** *May, might, can, could, often, typically, generally, in many cases, tends to* applied at the same rate to everything. Hedge what genuinely needs it. State the rest flat. A page on which nothing is asserted is a page with nothing in it.

**The heading-as-question.** *What is X? Why does X matter? How do you get started with X?* This is an SEO artifact, not a structure. If the piece has a real shape, the headings will name its parts.

**The bolded key term.** Bolding every term of art on first use, or bolding one phrase per paragraph for emphasis, makes a page look like a slide deck and tells the reader you do not trust your sentences to carry weight. Bold for genuine scanning aids, not for emphasis.

**The em dash for drama.** One or two in a piece is fine. A dash every third sentence is a rhythm tic. Zinsser is fond of the dash and describes its two legitimate uses: amplifying in the second half of a sentence what the first half claimed, and setting off a parenthetical inside a longer sentence. Beyond that, use a period.

**The closing summary.** Covered at length in SKILL.md. It is the loudest single tell and the easiest fix.

---

## 7. The rhythm signature

Detectors measure this and so do readers, unconsciously. It is also the fault Zinsser addresses when he tells you to read aloud and listen for sentences that all move at the same plodding gait.

| Symptom | Check | Repair |
|---|---|---|
| Uniform sentence length | No three consecutive sentences within three words of each other | Break one in half. Fuse two. Drop in a four-word sentence. |
| Uniform paragraph length | Scan the left margin; if every block is the same height, it is machine-shaped | Let one paragraph run long and the next be a single line |
| Every paragraph topic-sentence-first | Vary it. Some paragraphs earn their point at the end | Move the point of one or two paragraphs to the last sentence |
| Every sentence a full independent clause | Count fragments and short sentences: near zero is a signal | Let one fragment stand where the rhythm calls for it |
| Syllable creep | Count three-syllable-plus words in a paragraph | Lincoln's Second Inaugural: 89% of words are one or two syllables |
| No dialogue, no quotation, no numbers | A page with no particulars is a page with no facts | Get a quote, a number, a name, a date |

---

## 8. Journalese, the 1976 version (Z)

Included because it is the same disease and the specimens are instructive. Adjectives used as nouns (*greats*, *notables*). Nouns used as verbs (*to host*, *to author*, *to impact*, *to gift*). Nouns chopped into verbs (*enthuse*, *emote*). Nouns padded into verbs (*beef up*, *put teeth into*). *Famed* diplomats, their *staffers*, the *upcoming* report, the note *fired off* from a sitting position.

Zinsser's worked example is a newsmagazine paragraph about a shot policeman: *shouldered his way*, *only to be met*, *crashing into his face*, *waging a lonely war*, *corruption that is rife*, *sending shock waves*, *New York's finest*. Every phrase is the nearest cliché. No surprise waits for us anywhere in it. We know we are in the hands of a hack and we stop reading.

The test he gives: if you write that someone *enjoyed a spell of illness* or that a business *has been enjoying a slump*, ask how much they enjoyed it.

---

## 9. What is allowed in

Guarding usage is only half the job. The other half is welcoming any word that brings strength or color.

Zinsser sat on the American Heritage Usage Panel and voted to admit *dropout* (clean and vivid), *escalate*, *trek*, *rambunctious*, *trigger*, *rile*, *shambles*, *tycoon*, *hassle*, *freak*, *launder*, *stonewall*. He rejected *notables*, *greats*, *upcoming*, *prioritize*, *input*, *feedback*, *disincentive*.

The rule he settled on, from Theodore Bernstein: **does the word fill a real need?** *Printout* named a thing that did not exist before and stayed where it belonged. *Input* was borrowed to mean *ideas* and has been cheapening sentences ever since.

The panel's pattern is worth copying: liberal about new words, conservative about grammar. Take in what the language needs. Keep the distinctions that carry meaning: *fewer* and *less*, *infer* and *imply*, *flout* and *flaunt*, *fortuitous* and *accidental*, *disinterested* and *uninterested*, *compare with* and *compare to*, *reference* and *allusion*. Incorrect usage loses you the readers you would most like to win.

---

## 10. Running the pass

For each paragraph:

1. Read it once for phrases that arrived without effort. Mark them.
2. For each mark, say aloud what the automatic phrase was.
3. Ask what specific thing is true here.
4. Write the specific thing. If you do not have it, write `[NEED: ...]`.
5. Check for the construction patterns in section 6, which survive word-level edits.
6. Run the rhythm checks in section 7 across the whole piece, not per paragraph.

Expect this pass to be slow. Zinsser spent an hour on one sentence about Venice and Versailles and considered it time well spent, because both he and the reader can tell when the finicky labor was rewarded.
