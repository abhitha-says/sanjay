# The five passes

A runnable checklist. Run in order, each as a separate look at the text. Do not merge them; the whole point is that each pass looks for one thing and is therefore mechanical enough to catch what rereading with intent will not.

Record the word count before you start.

---

## Before drafting

- [ ] The one point, written as a sentence
- [ ] The reduction: which corner of the subject, stated
- [ ] Person and tense, chosen
- [ ] Stance and attitude, chosen
- [ ] Register: would the user say these words aloud?
- [ ] The missing I: who is the person in this story?
- [ ] Facts on hand, and a list of what is missing

---

## Pass 1: Bracket

Cut what does no work. Target 50 percent of a first draft.

- [ ] Prepositions welded to verbs: *head up, free up, order up, face up to, reach out to*
- [ ] Adverbs repeating the verb: *blare loudly, grin widely, clench tightly*
- [ ] Adjectives stating a known fact: *tall skyscraper, yellow daffodils, final outcome*
- [ ] Qualifiers: *a bit, sort of, rather, quite, very, pretty much, in a sense, somewhat, arguably, virtually, admittedly, relatively*
- [ ] Long word where a short one fits (see `machine-tells.md` §2)
- [ ] Phrase where a word fits (see `machine-tells.md` §3)
- [ ] Announcements: *it should be noted, it's worth mentioning, it is interesting that, let me be clear*
- [ ] Sentences restating the previous sentence
- [ ] Sentences telling readers what they can work out themselves
- [ ] Word count check. Under 50 percent cut on a first draft usually means you did not look hard enough.

---

## Pass 2: Verbs

- [ ] Every *is, are, was, were, has, have, will be, being*: who did what?
- [ ] Every passive construction: name the actor, or justify keeping it
- [ ] Every dull-but-serviceable verb: is there one with color?
- [ ] Every vague verb: *stepped down* → resigned, retired, or fired?
- [ ] Concept nouns: sentences with no people and no working verb
- [ ] Noun chains: two or more nouns lashed together where one verb belongs

---

## Pass 3: Second choice

The pass this skill exists for. Slow on purpose.

For each phrase that arrived without effort:

- [ ] Name the automatic phrase aloud
- [ ] Reject it as the average phrase
- [ ] Ask what is specifically true here, and write that
- [ ] Category → member: is there a name, number, date, or place that replaces the category noun?
- [ ] Anything you cannot fill: `[NEED: ...]`. **Never invent a specific.**

Then sweep for constructions, which survive word-level edits:

- [ ] *Not just X, but Y* and its variants
- [ ] Reflexive threes in lists, clauses, examples, sections
- [ ] Participial tack-ons: *...ensuring X, ...making it Y, ...highlighting Z*
- [ ] Significance clauses: *This matters because, The implication is clear*
- [ ] False-balance paragraphs acknowledging objections that have no case
- [ ] Uniform hedging
- [ ] Question headings
- [ ] Bolded terms used for emphasis rather than scanning
- [ ] Repeated names replaced by synonyms: put the name back

---

## Pass 4: Trust the material

- [ ] Evaluations before facts: *surprisingly, predictably, of course, notably, importantly, remarkably*
- [ ] Overstatement: does every comparison survive a literal reading?
- [ ] Exclamation points, especially ones signalling a joke
- [ ] Over-explanation: anything the reader can infer from the fact you just gave
- [ ] The closing summary. Find it and delete it. The real ending is usually earlier.

---

## Pass 5: Ear

Read the whole piece aloud.

- [ ] No three consecutive sentences within three words of each other in length
- [ ] Paragraph heights vary down the left margin
- [ ] Syllable check: are most words one or two syllables?
- [ ] Every sentence pair: where did I leave the reader, and does this sentence pick them up there?
- [ ] Direction changes signalled at the front: *But, Yet, Still, Instead, Meanwhile, Now, Later*
- [ ] No sentence opening with *However*
- [ ] Contractions where they fall naturally; no *I'd / he'd / we'd*
- [ ] Last three words of each sentence carry the point
- [ ] Last sentence of each paragraph springs to the next
- [ ] The first paragraph: delete it and see whether the piece is better

---

## Before delivering

- [ ] The piece makes one point, and you can say which
- [ ] The person who started it is the person ending it
- [ ] Every `[NEED: ...]` is listed for the user
- [ ] Word count reported: `before -> after`
- [ ] Nothing in it that you would not say aloud to the reader
