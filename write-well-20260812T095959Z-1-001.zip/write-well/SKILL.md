---
name: write-well
description: "Write and rewrite nonfiction prose to the standard of William Zinsser's On Writing Well: plain, specific, warm, with every word that does no work removed. Built against the failure mode of machine-generated text, which reaches for the most probable phrase instead of the true one and comes out fluent, average, and recognizable on sight. TRIGGER whenever the deliverable is prose a human reads for its own sake: blog posts, essays, landing page and marketing copy, product announcements, launch notes, README and docs intros, newsletters, LinkedIn or X posts, cover letters, pitch and proposal narrative, About pages, case studies, memoir and personal essay, speeches, and any email or memo that has to persuade. Also trigger on requests to repair prose: 'make this sound human', 'this reads like AI', 'it got flagged', 'tighten this', 'make it less corporate', 'rewrite this paragraph', 'why is this boring', or when the user pastes writing and asks what is wrong with it. SKIP for scholarly manuscripts and peer review (use research-paper), for code, code comments, commit messages, and API reference tables, and for plain question-answering where the deliverable is a fact rather than a piece of writing."
user-invocable: true
---

# Write well

## The disease and why this skill exists

Machine prose fails in one diagnosable way: it reaches for the most probable phrase instead of the true one. Probability is an average, and the average of everything ever written about a subject is a description of the category, never a member of it. So the sentence comes out saying *various stakeholders* where the truth was *the two founders and their lawyer*, and *a range of performance improvements* where the truth was *the page loads in 300ms instead of 2.4 seconds*.

Zinsser diagnosed the identical disease in 1976 and called it clutter. Same mechanism, different cause: a writer who has not decided exactly what is true reaches for the phrase that covers everything and commits to nothing. His cure works here because it attacks the mechanism rather than the symptom.

Two things follow, and they govern everything below.

**The fix is not vocabulary substitution.** Swapping *delve* for *examine* leaves the sentence just as average. The fix is to find the specific fact underneath the general phrase and put that on the page instead. A word list helps you notice you are drifting; it cannot tell you what is true.

**The fix is not evading a detector.** Writing to defeat a classifier produces strange prose that fails in a new way. The goal is prose specific enough that no reader mistakes it for average, which is the same goal good writers have always had. Never tell the user this skill will beat a detector, and never optimize for that. Say what is true: writing that is genuinely particular does not read like the mean of a corpus, because it is not near the mean of anything.

## Four articles of faith

Clarity. Simplicity. Brevity. Humanity. Zinsser recited these to a room of school principals who could not write a sentence their own parents understood. Every rule below is one of these four made operational.

## The hard rule

**Never deliver a first draft.** Rewriting is not a polish step; it is where the writing happens. Very few sentences come out right the first time, and none come out right on the first try from a system that generates by likelihood. Draft, then run the five passes in the Rewrite section, then deliver. When the task is a revision of the user's existing text, report the word count before and after: `1,240 -> 690`. That number is the one piece of evidence the user gets that the passes actually ran.

If the draft is long enough that passes are expensive, cut scope, not passes. A tight 400 words beats a slack 900.

## Step 0: decide before drafting

Answer these five before writing a sentence. Guessing here wastes the whole draft. Ask the user only for what you genuinely cannot infer from the request or the surrounding material; decide the rest yourself and say what you decided.

1. **The one point.** Every piece should leave the reader with a single thought they did not have before. Not two, not five. One. Write it down as a sentence. If you cannot, you are not ready to write, and no amount of style will hide it.
2. **The reduction.** Nobody can write about a subject. Tolstoy could not write a book about war and peace; he wrote about particular people in a particular time. Decide which corner you are biting off. *The disappearance of small towns in Iowa* is not writable. One town is. Inside that town, one store or one family is better.
3. **Person and tense.** First person or third; past or present. Pick and hold it. You may move through time; you may not drift between stances.
4. **Stance and distance.** In what capacity are you addressing the reader, and with what attitude: involved, detached, amused, angry, plain? Any of them works. A mix of two does not. The travel piece that alternates between *my wife Ann and I* and *One can ride the picturesque ferry* has lost its reader by the third paragraph.
5. **Register.** Match how the user actually talks, not how their industry writes. Never write a sentence you would not say aloud to the reader. If the user does not say *moreover* or *leverage* or *individual* in conversation, those words do not go on the page.

Then a sixth, on audience, which needs translating. Zinsser says write for yourself, and he means: do not compose toward the average of what a reader might want, because that average is nobody. Writing for a client, the translation is: **write from one definite position.** The reader is not a committee. Maximal agreeableness is the exact shape of machine prose, and hedging every claim to keep everyone comfortable is how a piece becomes weightless. Craft and approval are separate concerns. Never lose a reader through sloppy work; never soften a true sentence to be liked.

## Find the missing I

Institutions do not write; people do. Readers identify with people, never with *profitability* or *utilization* or *pre-feasibility studies in the paperwork stage*.

Before drafting anything on behalf of a company, product, or team, find the human being in the story: the engineer who conceived the thing, the founder who got the call at 2am, the customer who could not finish checkout. Ask the user for that person if they are missing. One named person doing one specific thing will outperform three paragraphs of capability description.

If first person is not permitted, think *I* while you write, or draft in first person and remove the pronouns afterward. It warms the result even when the pronoun is gone.

## The lead

The first sentence exists to make the reader read the second. That is its entire job. The second exists to deliver them to the third.

A lead must do four things, in this order: catch the reader with something particular (a fact, a paradox, a surprise, an oddity, a question worth asking), tell them why this was written and why they should care, keep adding hard detail so the interest compounds, and hand off to the body without a seam. Length is whatever does the job. One sentence can be enough; six paragraphs is fine if every one of them pulls.

The single most reliable lead is **a story**, told from inside the action, with no stage-setting. Zinsser's example is Edmund Wilson opening the Dead Sea Scrolls with a Bedouin boy throwing a stone into a cave.

**Leads to retire on sight.** The future archaeologist. The visitor from Mars. The thing that happened *one day not long ago*. The what-do-these-people-have-in-common quiz. The dictionary definition. The rhetorical question addressed to *you*. *In today's fast-paced world.* Every one of these is a signal that the writer had no specific fact to open with and reached for a template.

**Test.** Delete your first paragraph. Often the piece starts better without it, because the first paragraph was throat-clearing: a self-conscious attempt at an introduction that says nothing. Keep deleting until you hit the paragraph where a real voice starts. Editors do this to professional writers constantly and are usually right.

## Draft

Get it down, knowing you will take half of it out. Rules that pay for themselves at draft time rather than in revision:

- **One thought per sentence.** Readers process one idea at a time, in sequence. When a sentence resists you, it is usually trying to carry two thoughts. Break it.
- **Sequence is everything.** Ask after every sentence: what does the reader want to know next? Answer that. Nowhere is this stricter than in technical explanation, where fact and deduction are the only permitted moves.
- **The upside-down pyramid, for anything explanatory.** Start with the one narrow fact the reader must have before anything else can land. Widen from there: what it means, what it changes, what it opens up. Readers understand broad implications only if they were handed a narrow fact first.
- **Every paragraph amplifies the one before it.** And the last sentence of each paragraph is the springboard to the next. Give it a twist, a surprise, a small snapper. A reader who smiles gives you one more paragraph.
- **Short paragraphs.** Writing is visual before it is verbal. Air around the text invites reading; a wall of type repels it. Two to four sentences is a good working range. Do not go to the other extreme and chop a train of thought into verbless fragments, which is condescension in a different costume.
- **Collect more than you can use.** A piece is strong in proportion to the surplus you chose from. Readers should feel you know more than you put down. When you have a choice of two good details, use one.

## Rewrite: five passes

Run them in order, each as a separate look at the text. They are mechanical on purpose. You cannot judge prose by rereading it with the intent that produced it; you will read in what you meant. Run the procedure instead.

### Pass 1: Bracket

Zinsser taught this to students at Yale by literally bracketing every component doing no useful work, then asking them to read the sentence without it.

Bracket and remove: the preposition welded to a verb that did not need it (*head up*, *free up*, *order up*, *face up to*). The adverb repeating the verb (*blare loudly*, *grin widely*, *clench tightly*). The adjective stating a known fact (*tall skyscraper*, *yellow daffodils*). Every qualifier (*a bit*, *sort of*, *rather*, *quite*, *very*, *pretty much*, *in a sense*, *somewhat*, *arguably*, *virtually*, *admittedly*). The long word standing where a short one fits. Every announcement of what you are about to do (*it should be noted*, *it is worth mentioning*, *it is interesting that*). And whole sentences: the one restating the previous sentence, and the one telling readers what they can work out themselves.

**Target: 50 percent of a first draft, with no information and no voice lost.** That is Zinsser's number, and it holds. When you cannot find the cut, you are not looking hard enough. Cut eight pages to four, then cut four to three. The three are better.

### Pass 2: Verbs

Verbs push the sentence. Passive verbs tug at it.

Find every *is, are, was, were, has, have, will be, being* and every passive construction. For each, ask: who did what? Put that person or thing in the subject slot and the action in a verb. Then pick a verb with color in it: *glitter, dazzle, twirl, beguile, scatter, swagger, poke, pamper, vex*. Never accept the merely serviceable verb, and never accept the verb that needs a preposition to finish its job.

Two related faults to hunt in the same pass:

**Concept nouns.** Sentences with no people and no working verbs, where all the meaning has been packed into an abstraction. *The common reaction is incredulous laughter* becomes *Most people just laugh with disbelief.* *Bemused cynicism isn't the only response to the old system* becomes *Some people respond to the old system by turning cynical.*

**Noun chains.** Two, three, or five nouns lashed together where one verb belongs. Nobody goes broke now; we have *money problem areas*. It does not rain; we have a *thunderstorm probability situation*. Zinsser's prize specimen: *Communication facilitation skills development intervention*. Not a person in sight, not a working verb, and it turns out to be a program that helps students write.

**Precision.** Do not say the president *stepped down*. Did he resign, retire, or get fired? Vague verbs are usually a place where the writer did not know the fact, and the reader can feel it.

### Pass 3: Second choice

**This is the pass that does the work this skill exists to do.** Everything else is craft you would apply to any prose; this attacks the specific failure of generated text.

Go through the draft phrase by phrase. For each one that arrived without effort, do three things:

1. **Name it.** Say what the automatic phrase was. *A range of improvements. Seamlessly integrates. Navigate the complexity. Powerful tool. In today's landscape.*
2. **Reject it.** Assume the first phrase is the average phrase, because it is.
3. **Ask what is actually true here**, and write that instead. Not a synonym. The fact underneath.

The move is nearly always **from the category to the member**. *Various stakeholders* becomes *the two founders and their lawyer*. *Significant performance gains* becomes *2.4 seconds down to 300 milliseconds*. *A wide range of industries* becomes *dentists, food trucks, and one funeral home*. *Recently* becomes *last Tuesday*.

Zinsser worked this way in the open. Needing to say that six travelers were in their fifties and sixties, he wrote something serviceable, rejected it, hunted, and landed on *from late middle age to Medicare*. Needing to say his group did not visit ordinary tourist cities, he tried London and Paris, then Rome and Cairo, then Madrid and Moscow, and finally got *Venice and Versailles*. Then he replaced *turn up* with *bob up*, a three-letter verb that paints a picture. That one sentence took him an hour and he did not begrudge a minute of it. No writing decision is too small to be worth real time.

Two supporting habits:

- **Repetition beats a bad synonym.** Never rename a thing just to avoid using its name twice. The tennis player who becomes *the gangling junior*, then *the Memphis native*, then *the Exeter graduate*, then *the racquet ace*, then *the redhead* has vanished. Say *the batter*, *the pitcher*, *the button* again. Deliberate repetition is also a device: it surprises the reader and refreshes them mid-sentence.
- **The quickest fix is deletion.** When a phrase resists every attempt at repair, ask whether you need it at all. Usually you do not, and the reason it was fighting you is that it was trying to do a job that did not exist.

Word lists, construction patterns, and the full substitution tables: `references/machine-tells.md`.

### Pass 4: Trust the material

Color is not a separate ingredient added to fact. Color is organic to the fact. Your job is to present the colorful fact and get out of the way.

Delete, on sight:

- **Evaluations placed in front of facts.** *Surprisingly*, *predictably*, *of course*, *notably*, *importantly*, *strikingly*, *remarkably*, *it is worth noting that*. These tell the reader what to feel before they have met the thing. Give them the fact and let them do their own marveling; they enjoy being allowed to think.
- **The significance clause.** The tacked-on ending that explains why the fact you just gave matters: *...highlighting the importance of X*, *...making it a powerful tool for Y*, *...underscoring the need for Z*. Cut the clause. If the fact does not carry its own weight, the fact was wrong, not underexplained.
- **Overstatement.** The living room did not look as if an atomic bomb had gone off. You did not seriously consider jumping out the window. Every inflation spends credibility you will need later, and one bogus detail makes a reader suspect everything after it.
- **The exclamation point**, except where the effect genuinely requires it. Never use one to signal that you were being funny. Humor works by understatement, and nothing about an exclamation point is subtle.
- **The closing summary.** Covered in the Ending section below, and it is the most common failure in generated prose.

Zinsser's demonstration: a scout tells him it takes a right-handed batter 4.3 seconds to reach first, and the average double play takes 4.3 seconds. He does not add a sentence noting how astonishing it is that three infielders and three throws fit into 4.3 seconds. He gives the number and stops. Later, told the caravan he flew to Timbuktu to see had last run 27 years earlier, he writes the fact flat, with no exclamation point, and lets it detonate on its own.

### Pass 5: Ear

Read the whole thing aloud. Readers hear prose in an inner ear whether or not they know it, so rhythm and sound are not decoration.

- **Vary sentence length.** Uniform length is the single loudest signal of machine composition, and it is also just dull. Check: no three consecutive sentences within three words of each other in length. An occasional very short sentence carries enormous punch and stays in the ear.
- **Prefer short words.** Of the 701 words in Lincoln's Second Inaugural, 505 are one syllable and 122 are two. Wilbur Cross's Thanksgiving Proclamation, which Zinsser holds up as a masterpiece of eloquence, contains no four-syllable words and ten three-syllable ones. Eloquence runs on plain nouns: *leaves, wind, frost, air, soil, labor, breath, body, justice, courage, peace, land, home*. After verbs, plain nouns are the strongest tool you have.
- **Check the link between every pair of sentences.** *The tragic hero of the play is Othello. Small and malevolent, Iago feeds his jealous suspicions.* Nothing is wrong with either sentence; the pair is broken, because the name still ringing in the reader's ear is Othello. Ask at every seam: where did I leave the reader, and does this sentence pick them up there?
- **Signal every change of direction at the front.** Start with *But* when you are reversing. There is no stronger word at the start of a sentence, and the old rule against it is worth unlearning. *Yet*, *Still*, *Instead*, *Thus*, *Meanwhile*, *Now*, *Later*, *Today* each replace an entire dismal clause: *Despite the fact that all these dangers had been pointed out to him, he decided to go* is *Yet he decided to go*. Never open with *However*; it hangs there like a wet dishrag. Put it third or fourth word or use *but*.
- **Use contractions** where they fall naturally. *I'll*, *won't*, *can't*, *don't* sound like a person. Avoid *I'd*, *he'd*, *we'd*, which can mean *had* or *would* and make the reader backtrack. Never invent contractions like *could've*.
- **Listen for the last three words of each sentence.** They carry the stress and the reader hears them as the point. Trim trailing deadwood; move the heavy, new thing to the end.

## The ending

Give the last sentence nearly as much thought as the first.

**When you have made your point, stop.** Look for the nearest exit. The article that keeps going after it is finished becomes a drag, and a drag is a failure regardless of what came before.

Kill on sight any ending that begins *In sum*, *In conclusion*, *Ultimately*, *At the end of the day*, *To summarize*, or *What insights, then, can we glean*. These are compressed restatements of what you already said in full, and the reader hears the cranking. This is the strongest single tell of generated prose and the easiest to remove: usually the real ending is two or three paragraphs earlier, and the summary was added out of an obligation to a shape learned in school.

What works instead, roughly in order of reliability:

- **A quotation** with finality, humor, or an unexpected detail in it. Go back through your notes; often you will have thought *that's my ending* while collecting it.
- **A fact stated flat**, with no commentary, that reframes everything before it.
- **Full circle**: an echo of a note struck in the lead, which completes the journey the reader took with you.
- **A stop that arrives slightly early** and yet feels exactly right, like a curtain line. Startle first, aptness second.

You are not obliged to the actual shape of events. Zinsser's Timbuktu piece was supposed to end with the salt being unloaded and sold; he realized the real climax had already happened, in a nomad family offering to share their dinner, and he ended there. When the material tells you it is over, get out, pausing only to check that the person who started the piece is the person ending it.

## Voice and taste

Style is not applied to writing; it is the person doing the writing showing through. Trying to add style is like adding a toupee: the craftsmanship may be admirable, and it still does not look like anyone.

Develop one voice, and do not change it to fit the subject. Zinsser wrote a book about baseball and a book about jazz and refused to write either in the local dialect of its field. The commodity is the writer.

**Breeziness is not warmth.** The chatty register (*Believe you me*, *Here's the thing*, *Let's dive in*, *Pretty wild, right?*, *Spoiler:*) is not casual, it is condescending, and it is measurably harder to read than plain good English. The genuinely relaxed style, E. B. White's, is a disciplined act: formal grammar, plain precise words, cadences of a poet, made to look effortless by strenuous effort. Nobody ever stopped reading because the writing was too good; readers stop when they feel talked down to.

**Taste is mostly knowing what to leave out.** The pianist with taste puts every note to work; the one without drenches you in ripples. In prose the ripples are clichés, corny synonyms for plain words (*the top brass*, *the powers that be*), decorative adjectives, and the arch phrase reaching for a laugh it has not earned.

**Enjoyment is a technique, not a mood.** The reader has to feel the writer was feeling good. If something amuses you in the act of writing, put it in; it can always come out, and only you can put it in. Zinsser's Timbuktu piece carries small jokes he admits he planted purely to keep himself amused, and they are the reason the piece is readable.

**Eloquence, when it is called for, works by leaving things unsaid.** It touches echoes the reader already carries, and invites them to bring part of themselves. Lincoln's cadences are the King James Bible's because he had soaked in them since boyhood. Bombast is the counterfeit: the same reach for grandeur, executed with clichés, telling the reader everything and nourishing them with nothing.

## Working with the user

- **Deliver the prose, not a lecture about the prose.** Explanation is for when the user asks or is clearly learning.
- **When revising, report the cut.** `1,240 -> 690`. If they ask what changed, name the pass that caught it ("cut the closing summary; Pass 4") so they can run it themselves next time.
- **Preserve the user's voice, not a house voice.** When revising their words, the result should sound like them on a better day. If you cannot hear their voice in the source, ask for two paragraphs of something they wrote freely, or ask them to tell you the point out loud and write from that.
- **Do not invent facts to make prose specific.** This pass demands particulars, and the temptation to supply them is the single largest risk this skill carries. When a sentence needs a number, a name, or a date you do not have, write `[NEED: the actual load time]` and list every placeholder at the end. A fabricated specific is worse than the vague phrase it replaced, because the reader will believe it. Never soften this rule for the sake of a good sentence.
- **When asked only to critique**, diagnose without rewriting: name the fault, where it is, which pass catches it, and what the repair would be.
- **Push back on scope.** If the user asks for a piece that tries to make five points, say so and propose the one. Zinsser's lawyer student wanted to write a memoir, a personal essay, and an investigative report in one book; it took him three years to fit them under one roof.
- **Say when you are unsure a change is right.** Some of Zinsser's own choices were reluctant. Marking a compromise honestly is better than pretending every sentence landed.

## Reference map

| File | Read it when |
|---|---|
| `references/machine-tells.md` | Running Pass 3. The word lists, the construction patterns, the rhythm signature, and the full substitution tables |
| `references/sentences.md` | Any question about a single sentence: verbs, modifiers, punctuation, transitions, paragraphs, sound, that/which, pronouns |
| `references/structure.md` | Organizing anything longer than a page: unity, leads, section breaks, compression, endings, and Zinsser's annotated worked example |
| `references/forms.md` | The piece has a genre: business and institutional, technical and scientific, profile and interview, place, memoir, opinion, humor |
| `assets/rewrite-passes.md` | A runnable checklist of the five passes |

## Source

William Zinsser, *On Writing Well: The Classic Guide to Writing Nonfiction*, 25th anniversary (6th) edition, HarperCollins, 2001. Every principle here is his, and the examples cited are his unless marked otherwise.

Three things in this skill are not in the book, and are labeled where they appear: the diagnosis of machine prose in the opening section, the modern word and construction lists in `references/machine-tells.md`, and a handful of numeric checks (the three-consecutive-sentences length test, the fabrication rule) that mechanize advice Zinsser gives qualitatively. They are extensions of his method, not departures from it.

The book is 300 pages and this is a compression of it. When a question is not answered here, the answer is usually in the book.
